Contoh CRUD Sederhana dengan PHP dan MySQL
=========
Simple CRUD dengan php dan mysql

Technology
-------
HTML, CSS, PHP MURNI dan Database MySQL.

Design
---------
-

Fitur
---------
1. Input Data Users
2. Hapus Data Users
3. Edit Data Users
4. Display Data Users

Environment recomended
------------

- Webserver Apache 2.x (http://www.apachefriends.org, XAMPP 1.7.x) 
- PHP 5.x (http://www.apachefriends.org, XAMPP 1.7.x)
- MySQL 5.x (http://www.apachefriends.org, XAMPP 1.7.x)

Installation
------------
Cara Instal
1. Upload data backend di server php anda 
2. Import Database MySQL ke PHPMyAdmin
3. Setting agar sistem ada di root (http://localhost/simple_crud/) 

Contributing
------------
Jika menemukan masalah silahkan *Create Issue* & *Pull Request*.

Creadits
--------
Specials Thank

* Tobiweb ([TobiWeb.id](http://tobiweb.id))
* Referensi source code dan tutorial by Google

Donations
---------
*  No. rekening : 302501024583538  a.n Moh. Tobiin (BANK BRI)

Artikel
--------
Untuk Arikel bisa kunjung tautan berikut ini :

[Tobiweb ID](http://www.tobiweb.id)

Copyright & License
-------
Copyright (c) 2015 Tobiweb.id
[GNU Public License](http://www.gnu.org/licenses/gpl-3.0.html)